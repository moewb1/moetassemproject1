package com.example.moetassemproject1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
